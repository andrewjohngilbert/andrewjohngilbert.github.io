University of Surrey PhD Thesis Template
Adapted by Tony Orme for the Gilbertines Lab.
9th April 2026


File Preamble.tex contains values for:
    \summary for abstract
    \email for student
    \webpage for students github code repository
    \acknowledgements for students thanks

File main.tex contains values for:
    \title for the thesis title (line 92)
    \author for the students name (line 93)
    \thesupervisors for supervisors names (line 97 and 98)

In main.tex, each of the content files are included as follows:
    line 166 - Introduction/Introduction.tex
    line 167 - LiteratureReview/LiteratureReview.tex
    line 168 - Paper1/Content.tex
    line 169 - Paper2/Content.tex
    line 170 - Paper3/Content.tex
    line 171 - Conclusions/Conclusions.tex


==============================================================         
Everything below is for command line users only and not required
if you are using Overleaf.

main.tex uses the format "\include{Introduction/Introduction}" etc.,
for each of the content files. When using latexmk then a seperate
'out' directory must be created with each content directory
added to it. This is a requirement of the \include command as
it needs to write the temporary compile files into each 
content directory. An example of the file structure is shown below
where draft/ contains the .tex files, and out/ contains the files 
created by latexmk during compilation (Overleaf automatically creates
and hides these).

The directory tree example below shows that content directories such as 
out/Conclusuions/ have the intermediate latex file Conclusions.aux
Without the Conclusions/ directory added to out/ latexmk would throw
an error saying it cannot find a file.

An example of the command line executed from the draft/ directory is:
    latexmk -pdf -outdir=../out main.tex


├── draft
│   ├── acronym.tex
│   ├── ColourCrest.jpg
│   ├── Conclusions
│   │   └── Conclusions.tex
│   ├── crest.png
│   ├── Declaration.tex
│   ├── eimthesis.sty
│   ├── Introduction
│   │   └── Introduction.tex
│   ├── library_clean_.bib
│   ├── LiteratureReview
│   │   └── LiteratureReview.tex
│   ├── main.tex
│   ├── Paper1
│   │   └── Content.tex
│   ├── Paper2
│   │   └── Content.tex
│   ├── Paper3
│   │   └── Content.tex
│   └── Preamble.tex
├── out
│   ├── acronym.aux
│   ├── Conclusions
│   │   └── Conclusions.aux
│   ├── Declaration.aux
│   ├── Introduction
│   │   └── Introduction.aux
│   ├── LiteratureReview
│   │   └── LiteratureReview.aux
│   ├── main.aux
│   ├── main.bbl
│   ├── main.blg
│   ├── main.fdb_latexmk
│   ├── main.fls
│   ├── main.lof
│   ├── main.log
│   ├── main.lot
│   ├── main.out
│   ├── main.pdf
│   ├── main.synctex.gz
│   ├── main.toc
│   ├── Paper1
│   │   └── Content.aux
│   ├── Paper2
│   │   └── Content.aux
│   ├── Paper3
│   │   └── Content.aux
│   ├── Preamble.aux
│   └── symbols.aux
└── README.md
